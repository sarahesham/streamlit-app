"""Unit tests for extractor.py."""
import os
import tempfile
import shutil
from unittest.mock import Mock, patch, MagicMock
import pytest
from extractor import (
    _ensure_output_dirs,
    save_list_to_file,
    filter_links_by_keywords,
    _extract_course_urls_from_page,
    _navigate_to_next_page,
    scrape_abertay_courses
)


class TestEnsureOutputDirs:
    """Tests for _ensure_output_dirs function."""
    
    def test_creates_default_folder(self):
        """Test that default folder is created."""
        with tempfile.TemporaryDirectory() as tmpdir:
            original_dir = os.getcwd()
            try:
                os.chdir(tmpdir)
                result = _ensure_output_dirs()
                assert os.path.exists(result)
                assert "abertay" in result
            finally:
                os.chdir(original_dir)
    
    def test_creates_custom_folder(self):
        """Test that custom folder is created."""
        with tempfile.TemporaryDirectory() as tmpdir:
            original_dir = os.getcwd()
            try:
                os.chdir(tmpdir)
                result = _ensure_output_dirs("custom_folder")
                assert os.path.exists(result)
                assert "custom_folder" in result
            finally:
                os.chdir(original_dir)


class TestSaveListToFile:
    """Tests for save_list_to_file function."""
    
    def test_saves_items_to_file(self):
        """Test that items are saved correctly."""
        with tempfile.TemporaryDirectory() as tmpdir:
            original_dir = os.getcwd()
            try:
                os.chdir(tmpdir)
                items = ["url1", "url2", "url3"]
                result_path = save_list_to_file("test.txt", items)
                
                assert os.path.exists(result_path)
                with open(result_path, "r", encoding="utf-8") as f:
                    content = f.read()
                    assert "url1" in content
                    assert "url2" in content
                    assert "url3" in content
            finally:
                os.chdir(original_dir)
    
    def test_saves_empty_list(self):
        """Test that empty list is handled."""
        with tempfile.TemporaryDirectory() as tmpdir:
            original_dir = os.getcwd()
            try:
                os.chdir(tmpdir)
                result_path = save_list_to_file("empty.txt", [])
                
                assert os.path.exists(result_path)
                with open(result_path, "r", encoding="utf-8") as f:
                    content = f.read()
                    assert content == ""
            finally:
                os.chdir(original_dir)


class TestFilterLinksByKeywords:
    """Tests for filter_links_by_keywords function."""
    
    def test_filters_by_contains(self):
        """Test filtering with contains mode."""
        links = [
            "https://example.com/postgraduate-taught/course1",
            "https://example.com/undergraduate/course2",
            "https://example.com/other/course3"
        ]
        keywords = ["postgraduate-taught", "undergraduate"]
        
        with tempfile.TemporaryDirectory() as tmpdir:
            original_dir = os.getcwd()
            try:
                os.chdir(tmpdir)
                result = filter_links_by_keywords(
                    links, keywords, "filtered.txt", match_mode="contains"
                )
                
                assert len(result) == 2
                assert links[0] in result
                assert links[1] in result
                assert links[2] not in result
            finally:
                os.chdir(original_dir)
    
    def test_filters_by_segment(self):
        """Test filtering with segment mode."""
        links = [
            "https://example.com/postgraduate-taught/course1",
            "https://example.com/undergraduate/course2",
            "https://example.com/other/course3"
        ]
        keywords = ["postgraduate-taught"]
        
        with tempfile.TemporaryDirectory() as tmpdir:
            original_dir = os.getcwd()
            try:
                os.chdir(tmpdir)
                result = filter_links_by_keywords(
                    links, keywords, "filtered.txt", match_mode="segment"
                )
                
                assert len(result) == 1
                assert links[0] in result
            finally:
                os.chdir(original_dir)
    
    def test_empty_keywords(self):
        """Test that empty keywords return empty list."""
        links = ["https://example.com/course1"]
        
        with tempfile.TemporaryDirectory() as tmpdir:
            original_dir = os.getcwd()
            try:
                os.chdir(tmpdir)
                result = filter_links_by_keywords(links, [], "filtered.txt")
                assert result == []
            finally:
                os.chdir(original_dir)


class TestExtractCourseUrlsFromPage:
    """Tests for _extract_course_urls_from_page function."""
    
    def test_extracts_urls_from_page(self):
        """Test URL extraction from page."""
        mock_page = Mock()
        mock_link1 = Mock()
        mock_link1.get_attribute.return_value = (
            "https://search.abertay.ac.uk/s/redirect?url=https%3A%2F%2Fwww.abertay.ac.uk%2Fcourse1"
        )
        mock_link2 = Mock()
        mock_link2.get_attribute.return_value = (
            "https://search.abertay.ac.uk/s/redirect?url=%2Fcourse2"
        )
        
        mock_page.query_selector_all.return_value = [mock_link1, mock_link2]
        
        result = _extract_course_urls_from_page(mock_page)
        
        assert len(result) == 2
        assert "https://www.abertay.ac.uk/course1" in result
        assert "https://www.abertay.ac.uk/course2" in result
    
    def test_handles_malformed_urls(self):
        """Test that malformed URLs are skipped."""
        mock_page = Mock()
        mock_link = Mock()
        mock_link.get_attribute.return_value = "invalid-url"
        
        mock_page.query_selector_all.return_value = [mock_link]
        
        result = _extract_course_urls_from_page(mock_page)
        
        assert len(result) == 0


class TestNavigateToNextPage:
    """Tests for _navigate_to_next_page function."""
    
    def test_navigates_when_button_exists(self):
        """Test navigation when next button exists."""
        mock_page = Mock()
        mock_button = Mock()
        mock_page.query_selector.return_value = mock_button
        
        result = _navigate_to_next_page(mock_page)
        
        assert result is True
        mock_button.click.assert_called_once()
        mock_page.wait_for_timeout.assert_called_once()
    
    def test_returns_false_when_no_button(self):
        """Test that False is returned when no next button."""
        mock_page = Mock()
        mock_page.query_selector.return_value = None
        
        result = _navigate_to_next_page(mock_page)
        
        assert result is False


class TestScrapeAbertayCourses:
    """Tests for scrape_abertay_courses function."""
    
    @patch('extractor.sync_playwright')
    def test_scrapes_courses_successfully(self, mock_playwright):
        """Test successful course scraping."""
        # Mock playwright setup
        mock_browser = Mock()
        mock_page = Mock()
        
        # Mock page navigation and extraction
        mock_link = Mock()
        mock_link.get_attribute.return_value = (
            "https://search.abertay.ac.uk/s/redirect?url=https%3A%2F%2Fwww.abertay.ac.uk%2Fcourse1"
        )
        mock_page.query_selector_all.return_value = [mock_link]
        mock_page.query_selector.return_value = None  # No next button
        
        mock_browser.new_page.return_value = mock_page
        
        mock_p = Mock()
        mock_p.chromium.launch.return_value = mock_browser
        mock_playwright.return_value.__enter__.return_value = mock_p
        
        with tempfile.TemporaryDirectory() as tmpdir:
            original_dir = os.getcwd()
            try:
                os.chdir(tmpdir)
                count, urls = scrape_abertay_courses()
                
                assert count >= 0
                assert isinstance(urls, list)
            finally:
                os.chdir(original_dir)
                # Cleanup
                if os.path.exists("output_links_files"):
                    shutil.rmtree("output_links_files")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

