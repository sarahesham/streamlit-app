"""Test package for course extraction."""

