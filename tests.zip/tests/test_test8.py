"""Unit tests for course_extractor.py."""
import os
import json
import tempfile
from unittest.mock import Mock, patch, MagicMock
import pytest
from course_extractor import (
    CourseSchema,
    _get_extraction_schema,
    _get_extraction_prompt,
    extract_all_courses
)


class TestCourseSchema:
    """Tests for CourseSchema model."""
    
    def test_valid_course_schema(self):
        """Test that valid course data creates schema."""
        course_data = {
            "course_name": "Test Course",
            "level": "Undergraduate",
            "fees": "£9000",
            "duration": "3 years"
        }
        course = CourseSchema(**course_data)
        assert course.course_name == "Test Course"
        assert course.level == "Undergraduate"
    
    def test_minimal_course_schema(self):
        """Test that minimal course data (only name) works."""
        course_data = {"course_name": "Test Course"}
        course = CourseSchema(**course_data)
        assert course.course_name == "Test Course"
        assert course.level is None


class TestGetExtractionSchema:
    """Tests for _get_extraction_schema function."""
    
    def test_returns_valid_schema(self):
        """Test that schema is valid."""
        schema = _get_extraction_schema()
        assert schema["type"] == "object"
        assert "properties" in schema
        assert "course_name" in schema["properties"]
        assert "required" in schema
        assert "course_name" in schema["required"]


class TestGetExtractionPrompt:
    """Tests for _get_extraction_prompt function."""
    
    def test_returns_non_empty_prompt(self):
        """Test that prompt is not empty."""
        prompt = _get_extraction_prompt()
        assert len(prompt) > 0
        assert "course" in prompt.lower()


class TestExtractAllCourses:
    """Tests for extract_all_courses function."""
    
    @patch.dict(os.environ, {"FIRECRAWL_API_KEY": "test_key"})
    @patch('course_extractor.FirecrawlClient')
    @patch('course_extractor.extract_course_details')
    def test_extracts_courses_successfully(self, mock_extract, mock_client_class):
        """Test successful course extraction."""
        # Mock course data
        mock_course1 = {"course_name": "Course 1", "level": "Undergraduate"}
        mock_course2 = {"course_name": "Course 2", "level": "Postgraduate"}
        
        # Mock generator
        def mock_generator():
            yield ("Processing...", None)
            yield (None, mock_course1)
            yield ("Processing...", None)
            yield (None, mock_course2)
        
        mock_extract.return_value = mock_generator()
        mock_client = Mock()
        mock_client_class.return_value = mock_client
        
        with tempfile.TemporaryDirectory() as tmpdir:
            output_file = os.path.join(tmpdir, "test_courses.json")
            result = extract_all_courses(["url1", "url2"], output_file=output_file)
            
            assert len(result) == 2
            assert result[0]["course_name"] == "Course 1"
            assert result[1]["course_name"] == "Course 2"
            assert os.path.exists(output_file)
            
            # Verify JSON file content
            with open(output_file, "r", encoding="utf-8") as f:
                saved_data = json.load(f)
                assert len(saved_data) == 2
    
    @patch.dict(os.environ, {}, clear=True)
    @patch('course_extractor.load_dotenv')
    def test_raises_error_without_api_key(self, mock_load_dotenv):
        """Test that error is raised without API key."""
        mock_load_dotenv.return_value = None
        with pytest.raises(EnvironmentError):
            extract_all_courses(["url1"])
    
    @patch.dict(os.environ, {"FIRECRAWL_API_KEY": "test_key"})
    @patch('course_extractor.FirecrawlClient')
    @patch('course_extractor.extract_course_details')
    def test_deduplicates_courses(self, mock_extract, mock_client_class):
        """Test that duplicate courses are removed."""
        mock_course = {"course_name": "Duplicate Course", "level": "Undergraduate"}
        
        def mock_generator():
            yield (None, mock_course)
            yield (None, mock_course)  # Duplicate
        
        mock_extract.return_value = mock_generator()
        mock_client = Mock()
        mock_client_class.return_value = mock_client
        
        with tempfile.TemporaryDirectory() as tmpdir:
            output_file = os.path.join(tmpdir, "test_courses.json")
            result = extract_all_courses(["url1"], output_file=output_file)
            
            # Should only have one course despite duplicate
            assert len(result) == 1


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

